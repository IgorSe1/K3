import java.time.LocalDateTime;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        System.out.println("Система обліку паркувальних місць\n");

        System.out.println("Клас Parking:");
        Parking parking1 = new Parking();
        Parking parking2 = new Parking(false, true, "Автомобіль припаркований");
        System.out.println("parking1: " + parking1.toString());
        System.out.println("parking2: " + parking2.toString());
        System.out.println();

        System.out.println("Клас Transport:");
        Transport transport1 = new Transport();
        Transport transport2 = new Transport("Ford Mustang GTD", "MM1133VV",
                LocalDateTime.of(2025, 9, 26, 10, 30), null);
        System.out.println("transport1: " + transport1.toString());
        System.out.println("transport2: " + transport2.toString());
        System.out.println();

        System.out.println("Клас Count:");
        Count count1 = new Count();
        Count count2 = new Count(5000, 45, 1200, 7500, 15000);
        System.out.println("count1: " + count1.toString());
        System.out.println("count2: " + count2.toString());
        System.out.println();

        System.out.println("Клас PaymentCheck:");
        PaymentCheck payment1 = new PaymentCheck();
        PaymentCheck payment2 = new PaymentCheck("PAY123456", true, false,
                LocalDateTime.of(2025, 9, 26, 11, 15));
        System.out.println("payment1: " + payment1.toString());
        System.out.println("payment2: " + payment2.toString());
        System.out.println();

        System.out.println("Клас Staff:");
        Staff staff1 = new Staff();
        Staff staff2 = new Staff("Фернандо Алонсо", 43, "день", 5, "охоронець", "security");
        System.out.println("staff1: " + staff1.toString());
        System.out.println("staff2: " + staff2.toString());
        System.out.println();

        System.out.println("Клас Driver:");
        Driver driver1 = new Driver();
        Driver driver2 = new Driver("+380501234567", "verstappen@gmail.com",
                "Макс", "Ферстаппен", transport2);
        System.out.println("driver1: " + driver1.toString());
        System.out.println("driver2: " + driver2.toString());
        System.out.println();

        System.out.println("Клас Salary:");
        Salary salary1 = new Salary();
        Salary salary2 = new Salary(15000.0, 2500.0);
        System.out.println("salary1: " + salary1.toString());
        System.out.println("salary2: " + salary2.toString());
        System.out.println();

        System.out.println("Клас PublicUtilities:");
        PublicUtilities utilities1 = new PublicUtilities();
        PublicUtilities utilities2 = new PublicUtilities(12500.50, LocalDate.of(2025, 9, 15));
        System.out.println("utilities1: " + utilities1.toString());
        System.out.println("utilities2: " + utilities2.toString());
        System.out.println();

        System.out.println("Програма завершена");
    }
}