import java.time.LocalDateTime;

public class PaymentCheck {
    private String id;
    private boolean isPaid;
    private boolean isPaidbyCash;
    private LocalDateTime transaction_time;

    public PaymentCheck() {
        this.id = "";
        this.isPaid = false;
        this.isPaidbyCash = false;
        this.transaction_time = null;
    }

    public PaymentCheck(String id, boolean isPaid, boolean isPaidbyCash, LocalDateTime transaction_time) {
        this.id = id;
        this.isPaid = isPaid;
        this.isPaidbyCash = isPaidbyCash;
        this.transaction_time = transaction_time;
    }

    public boolean isPaid() {
        return false;
    }

    public boolean isPaidbyCash() {

        return false;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setPaid(boolean paid) {
        isPaid = paid;
    }

    public void setPaidbyCash(boolean paidbyCash) {
        isPaidbyCash = paidbyCash;
    }

    public LocalDateTime getTransaction_time() {
        return transaction_time;
    }

    public void setTransaction_time(LocalDateTime transaction_time) {
        this.transaction_time = transaction_time;
    }

    @Override
    public String toString() {
        return "PaymentCheck{" +
                "id='" + id + '\'' +
                ", isPaid=" + isPaid +
                ", isPaidbyCash=" + isPaidbyCash +
                ", transaction_time=" + transaction_time +
                '}';
    }
}