package parking.system;

public class Count {
    private int alltimeCustomers;
    private int inDayCustomers;
    private int inMonthCustomers;
    private int inHalfyearCustomers;
    private int inYearCustomers;

    public Count() {
        this.alltimeCustomers = 0;
        this.inDayCustomers = 0;
        this.inMonthCustomers = 0;
        this.inHalfyearCustomers = 0;
        this.inYearCustomers = 0;
    }

    public void incrementDailyCount() {
        inDayCustomers++;
        inMonthCustomers++;
        inHalfyearCustomers++;
        inYearCustomers++;
        alltimeCustomers++;
        System.out.println("Новий відвідувач зареєстрований. Всього за день: " + inDayCustomers);
    }

    public void resetDailyCount() {
        System.out.println("День завершено. Відвідувачів за день: " + inDayCustomers);
        inDayCustomers = 0;
    }

    public String getStatisticReport() {
        StringBuilder report = new StringBuilder();
        report.append("=== СТАТИСТИКА ВІДВІДУВАЧІВ ===\n");
        report.append("За день: ").append(inDayCustomers).append("\n");
        report.append("За місяць: ").append(inMonthCustomers).append("\n");
        report.append("За півроку: ").append(inHalfyearCustomers).append("\n");
        report.append("За рік: ").append(inYearCustomers).append("\n");
        report.append("За весь час: ").append(alltimeCustomers);
        return report.toString();
    }

    public int getTotalCustomers() {
        return alltimeCustomers;
    }

    void updateStatistics(int daily, int monthly) {
        this.inDayCustomers = daily;
        this.inMonthCustomers = monthly;
    }

    @Override
    public String toString() {
        return String.format("Count{день=%d, місяць=%d, рік=%d, всього=%d}", inDayCustomers, inMonthCustomers, inYearCustomers, alltimeCustomers);
    }
}
