package parking.system;

public class Driver {
    private String phonenumber;
    private String email;
    private String name;
    private String surname;
    private Transport transport;

    public Driver(String name, String surname) {
        this.name = name;
        this.surname = surname;
        this.phonenumber = "";
        this.email = "";
        this.transport = null;
    }

    public Driver(String name, String surname, String phone, String email) {
        this.name = name;
        this.surname = surname;
        this.phonenumber = phone;
        this.email = email;
        this.transport = null;
    }

    public void registerVehicle(Transport transport) {
        this.transport = transport;
        System.out.println("Водій " + getFullName() + " зареєстрував автомобіль: " + transport.getVehicleInfo());
    }

    public void updateContact(String phone, String email) {
        this.phonenumber = phone;
        this.email = email;
        System.out.println("Контактні дані оновлено для " + getFullName());
    }

    public String getFullName() {
        return name + " " + surname;
    }

    public String getContactInfo() {
        return String.format("Телефон: %s, Email: %s", phonenumber.isEmpty() ? "не вказано" : phonenumber, email.isEmpty() ? "не вказано" : email);
    }

    Transport getVehicle() {
        return transport;
    }

    @Override
    public String toString() {
        return String.format("Driver{ім'я='%s', авто=%s, телефон='%s'}", getFullName(), transport != null ? transport.getVehicleInfo() : "не зареєстровано", phonenumber);
    }
}
