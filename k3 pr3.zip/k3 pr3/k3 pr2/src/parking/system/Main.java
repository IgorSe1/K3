package parking.system;

import java.util.*;

public class 
Main {
    private static final Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== СИСТЕМА ОБЛІКУ ПАРКУВАЛЬНИХ МІСЦЬ ===\n");

        List<Driver> drivers = new ArrayList<>();
        List<Transport> transports = new ArrayList<>();
        List<Parking> spots = new ArrayList<>();

        int nSpots = askInt("Скільки створити паркомісць? ");
        for (int i = 1; i <= nSpots; i++) spots.add(new Parking(i));
        System.out.println("Створено: " + spots.size() + " місць\n");

        boolean run = true;
        while (run) {
            System.out.println("""
                    Меню:
                    1) Додати авто
                    2) Додати водія і прив'язати авто
                    3) Показати авто
                    4) Показати водіїв
                    5) Показати місця
                    6) Паркувати водія на місце
                    7) Звільнити місце
                    8) Оплата місця
                    9) Показати чеки прикладом
                    0) Вихід
                    """);
            int c = askInt("Обрати: ");
            switch (c) {
                case 1 -> {
                    String model = askStr("Модель авто: ");
                    String number = askStr("Держ. номер: ");
                    Transport t = new Transport(model, number);
                    transports.add(t);
                    System.out.println("Додано: " + t.getVehicleInfo() + "\n");
                }
                case 2 -> {
                    if (transports.isEmpty()) {
                        System.out.println("Спочатку додайте авто.\n");
                        break;
                    }
                    String name = askStr("Ім'я: ");
                    String surname = askStr("Прізвище: ");
                    String phone = askStr("Телефон: ");
                    String email = askStr("Email: ");
                    Driver d = new Driver(name, surname, phone, email);
                    showTransports(transports);
                    int ti = askInt("Оберіть індекс авто: ");
                    if (ti < 0 || ti >= transports.size()) {
                        System.out.println("Невірний індекс.\n");
                        break;
                    }
                    d.registerVehicle(transports.get(ti));
                    drivers.add(d);
                    System.out.println("Додано водія: " + d + "\n");
                }
                case 3 -> { showTransports(transports); System.out.println(); }
                case 4 -> { showDrivers(drivers); System.out.println(); }
                case 5 -> { showSpots(spots); System.out.println(); }
                case 6 -> {
                    if (drivers.isEmpty()) { System.out.println("Немає водіїв.\n"); break; }
                    showDrivers(drivers);
                    int di = askInt("Індекс водія: ");
                    if (di < 0 || di >= drivers.size()) { System.out.println("Невірний індекс.\n"); break; }
                    showSpots(spots);
                    int num = askInt("Номер місця: ");
                    Parking s = findSpot(spots, num);
                    if (s == null) { System.out.println("Немає такого місця.\n"); break; }
                    Transport t = drivers.get(di).getVehicle();
                    if (t == null) { System.out.println("У водія немає авто.\n"); break; }
                    if (s.checkAvailability()) s.occupySpot(t);
                    else System.out.println("Місце зайняте.");
                    System.out.println();
                }
                case 7 -> {
                    showSpots(spots);
                    int num = askInt("Номер місця: ");
                    Parking s = findSpot(spots, num);
                    if (s == null) { System.out.println("Немає такого місця.\n"); break; }
                    s.freeSpot();
                    System.out.println(s + "\n");
                }
                case 8 -> {
                    showSpots(spots);
                    int num = askInt("Номер місця: ");
                    Parking s = findSpot(spots, num);
                    if (s == null) { System.out.println("Немає такого місця.\n"); break; }
                    double amount = askDouble("Сума: ");
                    boolean cash = askStr("Спосіб (cash/card): ").trim().equalsIgnoreCase("cash");
                    PaymentCheck pc = new PaymentCheck("PAY" + System.currentTimeMillis());
                    pc.processPayment(amount, cash);
                    pc.confirmPayment();
                    s.markAsPaid();
                    System.out.println(pc.getPaymentReceipt() + "\n");
                }
                case 9 -> {
                    PaymentCheck p1 = new PaymentCheck("PAY001");
                    p1.processPayment(50.0, true);
                    p1.confirmPayment();
                    System.out.println(p1.getPaymentReceipt() + "\n");
                }
                case 0 -> run = false;
                default -> System.out.println("Невірний вибір.\n");
            }
        }
        System.out.println("Завершення роботи.");
    }

    private static int askInt(String msg) {
        System.out.print(msg);
        while (!in.hasNextInt()) { in.next(); System.out.print("Введіть число: "); }
        int v = in.nextInt(); in.nextLine(); return v;
    }
    private static double askDouble(String msg) {
        System.out.print(msg);
        while (!in.hasNextDouble()) { in.next(); System.out.print("Введіть число: "); }
        double v = in.nextDouble(); in.nextLine(); return v;
    }
    private static String askStr(String msg) {
        System.out.print(msg);
        return in.nextLine();
    }
    private static void showTransports(List<Transport> ts) {
        if (ts.isEmpty()) { System.out.println("(порожньо)"); return; }
        for (int i = 0; i < ts.size(); i++) System.out.println(i + ") " + ts.get(i).getVehicleInfo());
    }
    private static void showDrivers(List<Driver> ds) {
        if (ds.isEmpty()) { System.out.println("(порожньо)"); return; }
        for (int i = 0; i < ds.size(); i++) System.out.println(i + ") " + ds.get(i));
    }
    private static void showSpots(List<Parking> ss) {
        if (ss.isEmpty()) { System.out.println("(нема місць)"); return; }
        ss.forEach(s -> System.out.println("Місце #" + s.getSpotNumber() + " -> " + s));
    }
    private static Parking findSpot(List<Parking> ss, int number) {
        for (Parking s : ss) if (s.getSpotNumber() == number) return s;
        return null;
    }
}
