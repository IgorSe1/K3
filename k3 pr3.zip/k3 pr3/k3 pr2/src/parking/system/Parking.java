package parking.system;

public class Parking {
    private boolean isFree;
    private boolean isPaid;
    private String parkplaceInfo;
    private int parkingSpotNumber;
    private Transport currentTransport;

    public Parking(int spotNumber) {
        this.parkingSpotNumber = spotNumber;
        this.isFree = true;
        this.isPaid = false;
        this.parkplaceInfo = "Паркомісце #" + spotNumber + " вільне";
        this.currentTransport = null;
    }

    public boolean checkAvailability() {
        return isFree;
    }

    public void occupySpot(Transport transport) {
        if (isFree) {
            this.isFree = false;
            this.currentTransport = transport;
            this.parkplaceInfo = "Зайнято: " + transport.getVehicleInfo();
            transport.registerEntry();
        } else {
            System.out.println("Місце вже зайняте!");
        }
    }

    public void freeSpot() {
        if (!isFree && currentTransport != null) {
            currentTransport.registerExit();
            this.isFree = true;
            this.isPaid = false;
            this.currentTransport = null;
            this.parkplaceInfo = "Паркомісце #" + parkingSpotNumber + " звільнено";
        }
    }

    public void markAsPaid() {
        if (!isFree) {
            this.isPaid = true;
            System.out.println("Оплату підтверджено для місця #" + parkingSpotNumber);
        }
    }

    public String getParkingInfo() {
        return String.format("Місце #%d: %s, Оплачено: %s", parkingSpotNumber, isFree ? "Вільно" : "Зайнято", isPaid ? "Так" : "Ні");
    }

    int getSpotNumber() {
        return parkingSpotNumber;
    }

    protected void updateInfo(String info) {
        this.parkplaceInfo = info;
    }

    @Override
    public String toString() {
        return getParkingInfo();
    }
}
