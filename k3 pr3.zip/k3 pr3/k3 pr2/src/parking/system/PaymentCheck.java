package parking.system;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PaymentCheck {
    private String id;
    private boolean paid;
    private boolean paidByCash;
    private LocalDateTime transactionTime;
    private double amount;

    public PaymentCheck(String id) {
        this.id = id;
        this.paid = false;
        this.paidByCash = false;
        this.transactionTime = null;
        this.amount = 0.0;
    }

    public void processPayment(double amount, boolean cash) {
        this.amount = amount;
        this.paidByCash = cash;
        this.transactionTime = LocalDateTime.now();
        this.paid = true;
        System.out.println("Оплата " + amount + " грн проведена " + (cash ? "готівкою" : "карткою") + " о " + transactionTime.format(DateTimeFormatter.ofPattern("HH:mm")));
    }

    public void confirmPayment() {
        if (paid) System.out.println("Платіж #" + id + " підтверджено");
        else System.out.println("Платіж #" + id + " ще не проведено");
    }

    public boolean verifyPayment() {
        return paid && amount > 0;
    }

    public String getPaymentReceipt() {
        if (!paid) return "Чек недоступний - оплата не проведена";
        return String.format("ЧЕК #%s\nСума: %.2f грн\nСпосіб: %s\nЧас: %s", id, amount, paidByCash ? "Готівка" : "Картка", transactionTime.format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm")));
    }

    double getAmount() {
        return amount;
    }

    protected void updateTransactionTime() {
        this.transactionTime = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return String.format("PaymentCheck{id='%s', сума=%.2f, оплачено=%s}", id, amount, paid ? "Так" : "Ні");
    }
}
