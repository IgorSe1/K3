package parking.system;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class PublicUtilities {
    private double payment;
    private LocalDate paymentDate;
    private String utilityType;
    private LocalDate dueDate;

    public PublicUtilities(String utilityType) {
        this.utilityType = utilityType;
        this.payment = 0.0;
        this.paymentDate = null;
        this.dueDate = LocalDate.now().plusMonths(1);
    }

    public void makePayment(double amount) {
        this.payment = amount;
        this.paymentDate = LocalDate.now();
        System.out.println("Оплата за " + utilityType + ": " + amount + " грн проведена " + paymentDate.format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
    }

    public boolean isPaymentDue() {
        if (paymentDate == null) return true;
        return LocalDate.now().isAfter(dueDate);
    }

    public String getPaymentInfo() {
        if (paymentDate == null) return String.format("%s: Не оплачено. Термін: %s", utilityType, dueDate.format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
        return String.format("%s: %.2f грн, оплачено %s", utilityType, payment, paymentDate.format(DateTimeFormatter.ofPattern("dd.MM.yyyy")));
    }

    void setPaymentDate(LocalDate date) {
        this.paymentDate = date;
    }

    @Override
    public String toString() {
        return String.format("PublicUtilities{тип='%s', сума=%.2f, дата=%s}", utilityType, payment, paymentDate != null ? paymentDate.format(DateTimeFormatter.ofPattern("dd.MM.yyyy")) : "не оплачено");
    }
}
