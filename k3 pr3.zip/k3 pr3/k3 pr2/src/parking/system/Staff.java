package parking.system;

public class Staff {
    private String name;
    private int age;
    private String workshift;
    private int workExperience;
    private String workPosition;
    private String staffKind;

    public Staff(String name, String workPosition) {
        this.name = name;
        this.workPosition = workPosition;
        this.age = 0;
        this.workshift = "не призначено";
        this.workExperience = 0;
        this.staffKind = determineStaffKind(workPosition);
    }

    public Staff(String name, int age, String workPosition, String staffKind) {
        this.name = name;
        this.age = age;
        this.workPosition = workPosition;
        this.staffKind = staffKind;
        this.workshift = "день";
        this.workExperience = 0;
    }

    private String determineStaffKind(String position) {
        if (position.toLowerCase().contains("охорон")) return "security";
        if (position.toLowerCase().contains("прибирал")) return "cleaning";
        return "other";
    }

    public void assignShift(String shift) {
        this.workshift = shift;
        System.out.println(name + " призначено на зміну: " + shift);
    }

    public void promoteEmployee(String newPosition) {
        System.out.println(name + " підвищено з посади '" + workPosition + "' на посаду '" + newPosition + "'");
        this.workPosition = newPosition;
    }

    public int calculateExperience() {
        return workExperience;
    }

    public String getEmployeeInfo() {
        return String.format("%s, %d років, %s, стаж: %d років", name, age, workPosition, workExperience);
    }

    String getPosition() {
        return workPosition;
    }

    protected void incrementExperience() {
        workExperience++;
        System.out.println("Стаж " + name + " збільшено до " + workExperience + " років");
    }

    @Override
    public String toString() {
        return String.format("Staff{ім'я='%s', вік=%d, посада='%s', зміна='%s'}", name, age, workPosition, workshift);
    }
}
