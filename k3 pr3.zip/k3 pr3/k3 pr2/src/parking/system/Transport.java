package parking.system;

import java.time.LocalDateTime;
import java.time.Duration;
import java.time.format.DateTimeFormatter;

public class Transport {
    private String carModel;
    private String carGovnumber;
    private LocalDateTime enterDate;
    private LocalDateTime exitDate;

    public Transport(String carModel, String carGovnumber) {
        this.carModel = carModel;
        this.carGovnumber = carGovnumber;
        this.enterDate = null;
        this.exitDate = null;
    }

    public void registerEntry() {
        this.enterDate = LocalDateTime.now();
        System.out.println("Автомобіль " + carModel + " (" + carGovnumber + ") заїхав о " + enterDate.format(DateTimeFormatter.ofPattern("HH:mm")));
    }

    public void registerExit() {
        this.exitDate = LocalDateTime.now();
        System.out.println("Автомобіль " + carModel + " виїхав о " + exitDate.format(DateTimeFormatter.ofPattern("HH:mm")));
    }

    public String getVehicleInfo() {
        return carModel + " [" + carGovnumber + "]";
    }

    public Duration calculateParkingDuration() {
        if (enterDate != null && exitDate != null) return Duration.between(enterDate, exitDate);
        else if (enterDate != null) return Duration.between(enterDate, LocalDateTime.now());
        return Duration.ZERO;
    }

    String getGovNumber() {
        return carGovnumber;
    }

    protected void updateModel(String model) {
        this.carModel = model;
    }

    @Override
    public String toString() {
        return String.format("Transport{model='%s', number='%s', entered=%s, exited=%s}", carModel, carGovnumber, enterDate != null ? enterDate.format(DateTimeFormatter.ofPattern("HH:mm")) : "не заїжджав", exitDate != null ? exitDate.format(DateTimeFormatter.ofPattern("HH:mm")) : "не виїжджав");
    }
}
