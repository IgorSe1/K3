package parking.partner;

import parking.system.ParkingSpot;
import parking.system.Vehicle;
import parking.system.PaymentBase;

public class ExternalTest {
    public static void demo(ParkingSpot spot, Vehicle v, PaymentBase pay) {
        System.out.println("Інший пакет: package-private недоступний, працюємо лише через public API.");
        System.out.println(spot.getParkingInfo() + " | " + v.getVehicleInfo());
    }
}
