package parking.system;

public class AccessibleParking extends Parking {
    public AccessibleParking(int spotNumber) { super(spotNumber); }
    @Override double tariffPerHour() { return 20.0; }
}
