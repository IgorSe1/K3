package parking.system;

public class CardPayment extends PaymentCheck {
    public CardPayment(String id) { super(id); }
    @Override public void processPayment(double amount, boolean cash) {
        super.processPayment(amount, false);
        System.out.println("Комісія банку застосована");
    }
}
