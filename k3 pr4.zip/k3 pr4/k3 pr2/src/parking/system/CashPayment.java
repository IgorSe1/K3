package parking.system;

public class CashPayment extends PaymentCheck {
    public CashPayment(String id) { super(id); }
    @Override public void processPayment(double amount, boolean cash) {
        super.processPayment(amount, true);
        System.out.println("Видано фіскальний чек для готівки");
    }
}
