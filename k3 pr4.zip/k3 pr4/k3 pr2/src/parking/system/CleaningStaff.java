package parking.system;

public class CleaningStaff extends Staff {
    public CleaningStaff(String name) { super(name, "прибиральник"); }

    public CleaningStaff(String name, int age, String position, String department) {
        super(name, age, position, department);
    }

    public void dailyClean() {
        System.out.println("Прибиральниця " + getName() + " виконує щоденне прибирання.");
    }

    @Override public String role() { return "CleaningStaff"; }
}

