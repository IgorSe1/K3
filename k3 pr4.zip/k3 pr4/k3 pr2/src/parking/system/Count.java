package parking.system;

public class Count {
    private int alltimeCustomers;
    private int inDayCustomers;
    private int inMonthCustomers;
    private int inHalfyearCustomers;
    private int inYearCustomers;

    public Count() {
        this.alltimeCustomers = 0;
        this.inDayCustomers = 0;
        this.inMonthCustomers = 0;
        this.inHalfyearCustomers = 0;
        this.inYearCustomers = 0;
    }

    public void incrementDailyCount() {
        inDayCustomers++; inMonthCustomers++; inHalfyearCustomers++; inYearCustomers++; alltimeCustomers++;
        System.out.println("Новий відвідувач. Всього за день: " + inDayCustomers);
    }

    public void resetDailyCount() { System.out.println("День завершено. За день: " + inDayCustomers); inDayCustomers = 0; }
    public String getStatisticReport() {
        return "=== СТАТИСТИКА ===\nЗа день: " + inDayCustomers + "\nЗа місяць: " + inMonthCustomers +
                "\nЗа півроку: " + inHalfyearCustomers + "\nЗа рік: " + inYearCustomers + "\nЗа весь час: " + alltimeCustomers;
    }
    public int getTotalCustomers() { return alltimeCustomers; }
    void updateStatistics(int daily, int monthly) { this.inDayCustomers = daily; this.inMonthCustomers = monthly; } // package-private
    @Override public String toString() { return String.format("Count{день=%d, місяць=%d, рік=%d, всього=%d}", inDayCustomers, inMonthCustomers, inYearCustomers, alltimeCustomers); }
}

