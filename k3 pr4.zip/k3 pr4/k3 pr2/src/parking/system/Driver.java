package parking.system;

public class Driver extends Person {
    private Transport transport;

    public Driver(String name, String surname) { super(name, surname); }
    public Driver(String name, String surname, String phone, String email) { super(name, surname, phone, email); }

    public void registerVehicle(Transport t) {
        this.transport = t;
        System.out.println("Водій " + fullName() + " зареєстрував автомобіль: " + t.getVehicleInfo());
    }
    public void updateContact(String phone, String email) { this.phone = phone; this.email = email; }

    public String getContactInfo() {
        return "Телефон: " + (phone == null || phone.isBlank() ? "-" : phone) + ", Email: " + (email == null || email.isBlank() ? "-" : email);
    }

    Transport getVehicle() { return transport; } // package-private

    @Override public String role() { return "Driver"; }

    @Override public String toString() {
        return "Driver{ім'я='" + fullName() + "', авто=" + (transport != null ? transport.getVehicleInfo() : "не зареєстровано") + ", телефон='" + phone + "'}";
    }
}

