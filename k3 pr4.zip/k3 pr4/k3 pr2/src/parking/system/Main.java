package parking.system;

import java.util.*;

public class Main {
    private static final Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== СИСТЕМА ОБЛІКУ ПАРКУВАЛЬНИХ МІСЦЬ ===\n");

        SecurityStaff guard = new SecurityStaff("Олег Іванов", 40, "охоронець", "security");
        CleaningStaff cleaner = new CleaningStaff("Марія Коваленко", 32, "прибиральниця", "cleaning");

        guard.assignShift("денна");
        System.out.println(guard.getPosition() + " " + guard.getName() + " заступив на " + guard.getWorkShift() + " зміну.\n");

        List<Driver> drivers = new ArrayList<>();
        List<Transport> transports = new ArrayList<>();
        List<Parking> spots = new ArrayList<>();
        List<PaymentCheck> paymentHistory = new ArrayList<>();

        int nSpots = askInt("Скільки створити паркомісць? ");
        for (int i = 1; i <= nSpots; i++) spots.add(new Parking(i));
        System.out.println("Створено: " + spots.size() + " місць\n");

        boolean run = true;
        while (run) {
            System.out.println("""
                    Меню:
                    1) Додати авто
                    2) Додати водія і прив'язати авто
                    3) Показати авто
                    4) Показати водіїв
                    5) Показати місця
                    6) Паркувати водія на місце
                    7) Звільнити місце
                    8) Оплата місця
                    9) Показати чеки прикладом
                    0) Вихід
                    """);
            int c = askInt("Обрати: ");
            switch (c) {
                case 1 -> {
                    String model = askStr("Модель авто: ");
                    String number = askStr("Держ. номер: ").toUpperCase(Locale.ROOT);
                    Transport t = new Transport(model, number);
                    transports.add(t);
                    System.out.println("Додано: " + t.getVehicleInfo() + "\n");
                }
                case 2 -> {
                    if (transports.isEmpty()) {
                        System.out.println("Спочатку додайте авто.\n");
                        break;
                    }
                    String name = askStr("Ім'я: ");
                    String surname = askStr("Прізвище: ");
                    String phone = askStr("Телефон: ");
                    String email = askStr("Email: ");
                    Driver d = (phone.isBlank() && email.isBlank())
                            ? new Driver(name, surname)
                            : new Driver(name, surname, phone, email);

                    showTransports(transports);
                    int ti = askInt("Оберіть індекс авто: ");
                    if (ti < 0 || ti >= transports.size()) {
                        System.out.println("Невірний індекс.\n");
                        break;
                    }
                    d.registerVehicle(transports.get(ti));
                    drivers.add(d);
                    System.out.println("Додано водія: " + d + "\n");
                }
                case 3 -> { showTransports(transports); System.out.println(); }
                case 4 -> { showDrivers(drivers); System.out.println(); }
                case 5 -> { showSpots(spots); System.out.println(); }
                case 6 -> {
                    if (drivers.isEmpty()) { System.out.println("Немає водіїв.\n"); break; }
                    showDrivers(drivers);
                    int di = askInt("Індекс водія: ");
                    if (di < 0 || di >= drivers.size()) { System.out.println("Невірний індекс.\n"); break; }

                    showSpots(spots);
                    int num = askInt("Номер місця: ");
                    Parking s = findSpot(spots, num);
                    if (s == null) { System.out.println("Немає такого місця.\n"); break; }

                    Transport t = drivers.get(di).getVehicle();
                    if (t == null) { System.out.println("У водія немає авто.\n"); break; }

                    if (s.checkAvailability()) s.occupySpot(t);
                    else System.out.println("Місце зайняте.");
                    System.out.println();
                }
                case 7 -> {
                    showSpots(spots);
                    int num = askInt("Номер місця: ");
                    Parking s = findSpot(spots, num);
                    if (s == null) { System.out.println("Немає такого місця.\n"); break; }

                    String plate = askStr("Держ. номер авто, яке виїжджає: ").toUpperCase(Locale.ROOT);
                    Transport t = findTransportByPlate(transports, plate);
                    if (t == null) { System.out.println("Авто з таким номером не знайдено.\n"); break; }

                    s.freeSpot(t);
                    System.out.println(s + "\n");
                }
                case 8 -> {
                    showSpots(spots);
                    int num = askInt("Номер місця: ");
                    Parking s = findSpot(spots, num);
                    if (s == null) { System.out.println("Немає такого місця.\n"); break; }

                    double amount = askDouble("Сума: ");
                    String method = askStr("Спосіб (cash/card): ").trim().toLowerCase(Locale.ROOT);
                    boolean cash = method.equals("cash");

                    PaymentCheck pc = new PaymentCheck("PAY" + System.currentTimeMillis());
                    pc.processPayment(amount, cash);
                    pc.confirmPayment();
                    s.markAsPaid();

                    paymentHistory.add(pc);
                    System.out.println(pc.getPaymentReceipt() + "\n");
                }
                case 9 -> {
                    if (paymentHistory.isEmpty()) {
                        System.out.println("(Чеків поки що немає)\n");
                        break;
                    }
                    System.out.println("=== УСІ ЧЕКИ ===");
                    for (PaymentCheck pc : paymentHistory) {
                        System.out.println(pc.getPaymentReceipt());
                        System.out.println();
                    }
                }
                case 0 -> run = false;
                default -> System.out.println("Невірний вибір.\n");
            }
        }


        cleaner.assignShift("нічна");
        System.out.println(cleaner.getPosition() + " " + cleaner.getName() +
                " почала " + cleaner.getWorkShift() + " прибирання.");
        System.out.println("Система завершила роботу. Гарного дня!");
    }

    private static int askInt(String msg) {
        System.out.print(msg);
        while (!in.hasNextInt()) { in.next(); System.out.print("Введіть число: "); }
        int v = in.nextInt(); in.nextLine(); return v;
    }
    private static double askDouble(String msg) {
        System.out.print(msg);
        while (!in.hasNextDouble()) { in.next(); System.out.print("Введіть число: "); }
        double v = in.nextDouble(); in.nextLine(); return v;
    }
    private static String askStr(String msg) {
        System.out.print(msg);
        return in.nextLine();
    }
    private static void showTransports(List<Transport> ts) {
        if (ts.isEmpty()) { System.out.println("(порожньо)"); return; }
        for (int i = 0; i < ts.size(); i++) System.out.println(i + ") " + ts.get(i).getVehicleInfo());
    }
    private static void showDrivers(List<Driver> ds) {
        if (ds.isEmpty()) { System.out.println("(порожньо)"); return; }
        for (int i = 0; i < ds.size(); i++) System.out.println(i + ") " + ds.get(i));
    }
    private static void showSpots(List<Parking> ss) {
        if (ss.isEmpty()) { System.out.println("(нема місць)"); return; }
        ss.forEach(s -> System.out.println("Місце #" + s.getSpotNumber() + " -> " + s));
    }
    private static Parking findSpot(List<Parking> ss, int number) {
        for (Parking s : ss) if (s.getSpotNumber() == number) return s;
        return null;
    }
    private static Transport findTransportByPlate(List<Transport> list, String plate) {
        for (Transport t : list) {
            if (t.getGovNumber().equalsIgnoreCase(plate)) return t;
        }
        return null;
    }
}
