package parking.system;

public class Parking extends ParkingSpot {
    public Parking(int spotNumber) { super(spotNumber); }
    @Override double tariffPerHour() { return 30.0; }
}
