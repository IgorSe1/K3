package parking.system;

public abstract class ParkingSpot {
    protected boolean isFree = true;
    protected boolean isPaid = false;
    protected int spotNumber;

    protected ParkingSpot(int spotNumber) { this.spotNumber = spotNumber; }

    public boolean checkAvailability() { return isFree; }

    public void occupySpot(Vehicle v) {
        if (isFree) {
            isFree = false;
            System.out.println("Зайнято місце #" + spotNumber + " транспортом " + v.getVehicleInfo());
            v.registerEntry();
        } else {
            System.out.println("Місце #" + spotNumber + " зайняте");
        }
    }

    public void freeSpot(Vehicle v) {
        if (!isFree) {
            v.registerExit();
            isFree = true;
            isPaid = false;
            System.out.println("Місце #" + spotNumber + " звільнено");
        }
    }

    public void markAsPaid() {
        if (!isFree) {
            isPaid = true;
            System.out.println("Оплату підтверджено для #" + spotNumber);
        }
    }

    abstract double tariffPerHour();
    int getSpotNumber() { return spotNumber; }
    protected void updateInfo(String info) { /* hook */ }

    public String getParkingInfo() {
        return "Місце #" + spotNumber + ": " + (isFree ? "Вільно" : "Зайнято") + ", Оплачено: " + (isPaid ? "Так" : "Ні");
    }

    @Override public String toString() { return getParkingInfo(); }
}
