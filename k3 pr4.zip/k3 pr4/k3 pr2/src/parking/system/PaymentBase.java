package parking.system;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public abstract class PaymentBase {
    protected String id;
    protected boolean paid;
    protected boolean paidByCash;
    protected LocalDateTime transactionTime;
    protected double amount;

    protected PaymentBase(String id) { this.id = id; }

    public abstract void processPayment(double amount, boolean cash);

    public void confirmPayment() {
        System.out.println(paid ? "Платіж #" + id + " підтверджено" : "Платіж #" + id + " ще не проведено");
    }

    public boolean verifyPayment() { return paid && amount > 0; }

    public String getPaymentReceipt() {
        if (!paid) return "Чек недоступний - оплата не проведена";
        return "ЧЕК #" + id + "\nСума: " + String.format("%.2f", amount) + " грн\nСпосіб: " + (paidByCash ? "Готівка" : "Картка") +
                "\nЧас: " + transactionTime.format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"));
    }

    double getAmount() { return amount; }
    protected void updateTransactionTime() { this.transactionTime = LocalDateTime.now(); }
}
