package parking.system;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PaymentCheck extends PaymentBase {
    public PaymentCheck(String id) { super(id); }

    @Override
    public void processPayment(double amount, boolean cash) {
        this.amount = amount;
        this.paidByCash = cash;
        this.transactionTime = LocalDateTime.now();
        this.paid = true;
        System.out.println("Оплата " + amount + " грн (" + (cash ? "готівка" : "картка") + ") о " +
                transactionTime.format(DateTimeFormatter.ofPattern("HH:mm")));
    }

    @Override public String toString() {
        return "PaymentCheck{id='" + id + "', сума=" + amount + ", оплачено=" + (paid ? "Так" : "Ні") + "}";
    }
}
