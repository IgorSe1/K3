package parking.system;

public abstract class Person {
    protected String name;
    protected String surname;
    protected String phone;
    protected String email;

    protected Person(String name, String surname) {
        this(name, surname, "", "");
    }
    protected Person(String name, String surname, String phone, String email) {
        this.name = name;
        this.surname = surname;
        this.phone = phone;
        this.email = email;
    }

    public String fullName() { return name + " " + surname; }

    // 🔽 добавили публичные геттеры
    public String getName()     { return name; }
    public String getSurname()  { return surname; }
    public String getPhone()    { return phone; }
    public String getEmail()    { return email; }

    public abstract String role();
}
