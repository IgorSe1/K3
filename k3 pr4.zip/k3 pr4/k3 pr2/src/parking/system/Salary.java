package parking.system;

public class Salary {
    private double salaryRate;
    private double salarySupplement;
    private double totalSalary;

    public Salary(double salaryRate) {
        this.salaryRate = salaryRate;
        this.salarySupplement = 0.0;
        this.totalSalary = salaryRate;
    }

    public void addBonus(double bonus) {
        this.salarySupplement += bonus;
        calculateSalary();
        System.out.println("Додано бонус: " + bonus + " грн. Нова надбавка: " + salarySupplement);
    }

    public void calculateSalary() { this.totalSalary = salaryRate + salarySupplement; }
    public double getTotalSalary() { return totalSalary; }

    public void applyRaise(double percentage) {
        double increase = salaryRate * (percentage / 100.0);
        salaryRate += increase;
        calculateSalary();
        System.out.println("Підвищення зарплати на " + percentage + "%. Нова ставка: " + salaryRate);
    }

    double getBaseSalary() { return salaryRate; }

    @Override public String toString() { return String.format("Salary{ставка=%.2f, надбавки=%.2f, всього=%.2f грн}", salaryRate, salarySupplement, totalSalary); }
}
