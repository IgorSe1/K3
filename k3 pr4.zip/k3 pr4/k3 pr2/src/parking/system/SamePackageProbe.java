package parking.system;

public class SamePackageProbe {
    public static void demo(ParkingSpot spot, Vehicle v, PaymentBase pay) {
        System.out.println("✔ Той самий пакет: доступ до package-private дозволено.");
        System.out.println("Місце #" + spot.getSpotNumber() + ", сума платежу=" + pay.getAmount());
        if (spot.checkAvailability()) spot.occupySpot(v);
    }
}
