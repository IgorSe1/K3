package parking.system;

public class SecurityStaff extends Staff {
    public SecurityStaff(String name) { super(name, "охоронець"); }

    public SecurityStaff(String name, int age, String position, String department) {
        super(name, age, position, department);
    }

    @Override
    public void assignShift(String shift) {
        super.assignShift(shift);
        System.out.println("Охоронець отримав інструктаж безпеки.");
    }

    @Override public String role() { return "SecurityStaff"; }
}

