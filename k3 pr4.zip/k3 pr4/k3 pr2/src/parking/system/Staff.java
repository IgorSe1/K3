package parking.system;

public class Staff extends Person {
    protected String workshift = "не призначено";
    protected int workExperience = 0;
    protected String workPosition;
    protected String staffKind;

    public Staff(String name, String workPosition) {
        super(name, "");
        this.workPosition = workPosition;
        this.staffKind = kindFrom(workPosition);
    }
    public Staff(String name, int age, String workPosition, String staffKind) {
        super(name, "");
        this.workPosition = workPosition;
        this.staffKind = staffKind;
        this.workshift = "день";
    }

    private String kindFrom(String position) {
        String p = position.toLowerCase();
        if (p.contains("охорон")) return "security";
        if (p.contains("прибирал")) return "cleaning";
        return "other";
    }

    public void assignShift(String shift) { this.workshift = shift; System.out.println(name + " зміна: " + shift); }
    public void promoteEmployee(String newPosition) { System.out.println(name + " підвищено з '" + workPosition + "' на '" + newPosition + "'"); this.workPosition = newPosition; }
    public int calculateExperience() { return workExperience; }


    public String getPosition()   { return workPosition; }
    public String getWorkShift()  { return workshift; }

    protected void incrementExperience() { workExperience++; System.out.println("Стаж " + name + ": " + workExperience); }

    @Override public String role() { return "Staff"; }

    @Override public String toString() { return "Staff{ім'я='" + name + "', посада='" + workPosition + "', зміна='" + workshift + "'}"; }
}
