package parking.system;

public class Transport extends Vehicle {
    public Transport(String carModel, String carGovnumber) { super(carModel, carGovnumber); }
    @Override public String vehicleType() { return "Car"; }
    protected void updateModel(String model) { this.model = model; }
    @Override public String toString() { return "Transport{model='" + model + "', number='" + govNumber + "'}"; }
}
