package parking.system;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public abstract class Vehicle {
    protected String model;
    protected String govNumber;
    protected LocalDateTime enterDate;
    protected LocalDateTime exitDate;

    protected Vehicle(String model, String govNumber) { this.model = model; this.govNumber = govNumber; }

    public String getVehicleInfo() { return model + " [" + govNumber + "]"; }

    public void registerEntry() {
        enterDate = LocalDateTime.now();
        System.out.println(vehicleType() + " " + getVehicleInfo() + " заїхав о " + enterDate.format(DateTimeFormatter.ofPattern("HH:mm")));
    }
    public void registerExit() {
        exitDate = LocalDateTime.now();
        System.out.println(vehicleType() + " " + model + " виїхав о " + exitDate.format(DateTimeFormatter.ofPattern("HH:mm")));
    }

    public Duration calculateParkingDuration() {
        if (enterDate != null && exitDate != null) return Duration.between(enterDate, exitDate);
        if (enterDate != null) return Duration.between(enterDate, LocalDateTime.now());
        return Duration.ZERO;
    }

    String getGovNumber() { return govNumber; }
    public abstract String vehicleType();
}
